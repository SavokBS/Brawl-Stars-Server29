import time

class EventSlots:
    maps = [
        {
            'ID': 40, # Gem Grab
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 228, # Showdown
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 146, # Heist
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 82, # Bounty
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 24, # Brawl Ball
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 269, # Rampage
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },
        {
            'ID': 290, # Hot Zone
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },



    ]