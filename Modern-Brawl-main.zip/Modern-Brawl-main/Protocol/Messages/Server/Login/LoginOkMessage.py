from Utils.Writer import Writer


class LoginOkMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 20104
        self.version = 1

    def encode(self):
        self.writeLong(self.player.ID)
        self.writeLong(self.player.ID)
        self.writeString(self.player.token)

        self.writeString() # GameCenter ID
        self.writeString() # Facebook ID

        self.writeInt(26)
        self.writeInt(184)
        self.writeInt(1)

        self.writeString("dev")
        self.writeInt(0)    # Sessions Count
        self.writeInt(0)    # Played Time
        self.writeInt(0)    # Days Since Started Playing

        self.writeString()  # FacebookApp ID
        self.writeString()  # Server Time
        self.writeString()  # Account Created Date

        self.writeInt(1)
